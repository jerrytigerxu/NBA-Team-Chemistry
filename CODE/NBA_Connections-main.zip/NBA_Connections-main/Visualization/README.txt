VISUALIZATION VIEWING STEPS

VSCode --> Install Live Server (extension) --> Open 'dva_visualization.csv' --> Go Live (bottom right corner) using Chrome

- You can run it however you like, this is just the environment where the visualization was built / tested
- JSON data file is available to download and use locally (as a backup), but the HTML already points to the dataset on GitHub
